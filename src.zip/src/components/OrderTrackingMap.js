import React, { useRef, useEffect } from 'react';
import { View, StyleSheet, Text, Platform } from 'react-native';
import MapView, { Marker, Polyline, PROVIDER_GOOGLE, PROVIDER_DEFAULT } from 'react-native-maps';
import { Ionicons } from '@expo/vector-icons';
import { COLORS } from '../utils/constants';

// Real map version of the restaurant → customer route.
// - Straight dotted line by default (no extra API key needed).
// - If a rider position is known, the line splits into a solid "already
//   travelled" segment and a dashed "remaining" segment — same idea Zomato/
//   Swiggy use, just without road-snapping (see note at bottom of file for
//   how to upgrade to a real road-following polyline later).
export default function OrderTrackingMap({
  restaurant,   // { latitude, longitude, name }
  destination,  // { latitude, longitude, address }
  rider,        // { latitude, longitude, name } | null — appears once out_for_delivery
  height = 220,
}) {
  const mapRef = useRef(null);

  const hasRoute = !!(restaurant?.latitude && restaurant?.longitude && destination?.latitude && destination?.longitude);

  useEffect(() => {
    if (!hasRoute || !mapRef.current) return;
    const points = [
      { latitude: restaurant.latitude, longitude: restaurant.longitude },
      { latitude: destination.latitude, longitude: destination.longitude },
    ];
    if (rider?.latitude && rider?.longitude) {
      points.push({ latitude: rider.latitude, longitude: rider.longitude });
    }
    // Small delay lets the map finish its first native layout pass before fitting
    const t = setTimeout(() => {
      mapRef.current?.fitToCoordinates(points, {
        edgePadding: { top: 50, right: 50, bottom: 50, left: 50 },
        animated: true,
      });
    }, 300);
    return () => clearTimeout(t);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [hasRoute, rider?.latitude, rider?.longitude]);

  if (!hasRoute) {
    // No coordinates on this order yet (e.g. an old order placed before
    // lat/lng was captured) — fail gracefully instead of an empty map.
    return (
      <View style={[styles.fallback, { height }]}>
        <Ionicons name="map-outline" size={22} color={COLORS.gray} />
        <Text style={styles.fallbackText}>Map preview isn't available for this order.</Text>
      </View>
    );
  }

  const restaurantPoint = { latitude: restaurant.latitude, longitude: restaurant.longitude };
  const destinationPoint = { latitude: destination.latitude, longitude: destination.longitude };
  const riderPoint = rider?.latitude && rider?.longitude
    ? { latitude: rider.latitude, longitude: rider.longitude }
    : null;

  return (
    <View style={[styles.wrap, { height }]}>
      <MapView
        ref={mapRef}
        style={StyleSheet.absoluteFill}
        provider={Platform.OS === 'android' ? PROVIDER_GOOGLE : PROVIDER_DEFAULT}
        initialRegion={{
          latitude: (restaurantPoint.latitude + destinationPoint.latitude) / 2,
          longitude: (restaurantPoint.longitude + destinationPoint.longitude) / 2,
          latitudeDelta: Math.max(0.02, Math.abs(restaurantPoint.latitude - destinationPoint.latitude) * 1.8),
          longitudeDelta: Math.max(0.02, Math.abs(restaurantPoint.longitude - destinationPoint.longitude) * 1.8),
        }}
        pitchEnabled={false}
        toolbarEnabled={false}
      >
        {riderPoint ? (
          <>
            {/* Travelled leg — solid, restaurant → rider */}
            <Polyline
              coordinates={[restaurantPoint, riderPoint]}
              strokeColor={COLORS.green}
              strokeWidth={4}
            />
            {/* Remaining leg — dashed, rider → customer (this is the Zomato-style bit) */}
            <Polyline
              coordinates={[riderPoint, destinationPoint]}
              strokeColor={COLORS.primary}
              strokeWidth={4}
              lineDashPattern={[10, 10]}
            />
          </>
        ) : (
          // Nothing picked up yet — one dashed line, restaurant → customer
          <Polyline
            coordinates={[restaurantPoint, destinationPoint]}
            strokeColor={COLORS.primary}
            strokeWidth={4}
            lineDashPattern={[10, 10]}
          />
        )}

        <Marker coordinate={restaurantPoint} title={restaurant.name || 'Restaurant'} anchor={{ x: 0.5, y: 0.5 }}>
          <View style={[styles.pin, styles.pinPrimary]}>
            <Ionicons name="restaurant" size={14} color="#fff" />
          </View>
        </Marker>

        <Marker coordinate={destinationPoint} title="Delivery address" description={destination.address} anchor={{ x: 0.5, y: 0.5 }}>
          <View style={[styles.pin, styles.pinDark]}>
            <Ionicons name="location" size={14} color="#fff" />
          </View>
        </Marker>

        {riderPoint && (
          <Marker
            coordinate={riderPoint}
            title={rider.name || 'Delivery partner'}
            anchor={{ x: 0.5, y: 0.5 }}
            // rider moves the most often — this keeps re-renders from thrashing the native view
            tracksViewChanges={false}
          >
            <View style={[styles.pin, styles.pinRider]}>
              <Ionicons name="bicycle" size={15} color="#fff" />
            </View>
          </Marker>
        )}
      </MapView>
    </View>
  );
}

/*
  Upgrading to a real road-following route (curved, snapped to streets)
  instead of the straight dotted line:
  1. Call Google's Directions API (or a free alternative like OSRM) with
     origin = restaurant coords, destination = customer coords.
  2. Decode the returned `overview_polyline.points` (Google encodes it —
     use a small polyline-decoding helper, e.g. the `@mapbox/polyline` package).
  3. Pass the decoded array of {latitude, longitude} points into <Polyline
     coordinates={...} /> above instead of the 2-point straight line.
  This does need a billed Google Maps API key (Directions API), which is why
  it's not wired in by default here.
*/

const styles = StyleSheet.create({
  wrap: { borderRadius: 16, overflow: 'hidden', marginBottom: 12 },
  fallback: {
    borderRadius: 16, marginBottom: 12, backgroundColor: COLORS.white,
    alignItems: 'center', justifyContent: 'center', gap: 8, paddingHorizontal: 20,
  },
  fallbackText: { fontSize: 12, color: COLORS.gray, textAlign: 'center' },
  pin: {
    width: 28, height: 28, borderRadius: 14, alignItems: 'center', justifyContent: 'center',
    borderWidth: 2, borderColor: '#fff',
    shadowColor: '#000', shadowOffset: { width: 0, height: 1 }, shadowOpacity: 0.3, shadowRadius: 2, elevation: 3,
  },
  pinPrimary: { backgroundColor: COLORS.primary },
  pinDark: { backgroundColor: COLORS.black },
  pinRider: { backgroundColor: COLORS.green },
});